# Maintenance Manager Pro — static landing page (GitHub Pages)

This is a **static-only** page: an industrial/blue-collar warehouse themed
landing page, with all the app/login/dashboard functionality removed since
GitHub Pages can't run a server anyway.

## What's here
- `index.html` — single-file page. Rustic/futuristic warehouse aesthetic:
  steel-dark background, hazard-stripe dividers, hi-vis orange/yellow
  accents, a hand-built SVG scene (worker at a diagnostic HUD panel on the
  night shift) as the hero graphic.
- A "What's in the vault" section (PM schedules, GMP audits, RCA templates,
  training guides).
- A "From the author" / Books section linking straight out to the
  Amazon author page: https://www.amazon.com.au/stores/Amit-Boodram/author/B0H7YWG18P

## What's missing (on purpose)
No login, no sign-in button, no member dashboard, no reader, no admin panel,
no purchase verification, no Gumroad integration. It's a pure marketing page
that sends visitors to the Amazon author page. If you want purchase/download
gating back, that needs a real backend (Netlify or Vercel + Supabase), not
GitHub Pages.

## Deploying to GitHub Pages

1. Create a new GitHub repo (or use an existing one).
2. Add `index.html` to the **root** of the repo.
3. Commit and push:
   ```bash
   git init
   git add index.html README.md
   git commit -m "Static landing page"
   git branch -M main
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git push -u origin main
   ```
4. On GitHub: go to your repo → **Settings** → **Pages**.
   - Under "Build and deployment", set **Source** to "Deploy from a branch".
   - Set **Branch** to `main` and folder to `/ (root)`.
   - Save.
5. GitHub will give you a URL like
   `https://YOUR_USERNAME.github.io/YOUR_REPO/` within a minute or two.

### Custom domain (optional)
Add a file named `CNAME` (no extension) containing just your domain, e.g.:
```
maintainprovault.com
```
and point your domain's DNS at GitHub Pages per
https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site
